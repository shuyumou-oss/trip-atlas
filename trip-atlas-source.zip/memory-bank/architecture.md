# 行囊架构说明

## 当前状态

项目已迁入 React + TypeScript + Vite 单页应用；开发环境通过 Vite 中间件提供一个最小的本地 POI 搜索代理，并已接入高德地图服务。

| 路径 | 职责 |
|---|---|
| `index.html` | Vite 的 HTML 入口与 React 挂载节点。 |
| `src/main.tsx` | React 应用挂载入口，并加载共享样式。 |
| `src/workspace.css` | 蓝白旅行工作台视觉层；在旧样式后加载，负责总览、单日页、按需展开控件与响应式布局。 |
| `src/travel-book.css` | 用户选定的浅色旅行册主题，最后加载；奶白/墨蓝/复古红按钮、行式地点池及按日期编号着色的文件页签。workspace.css 保留结构与响应式职责。 |
| `src/App.tsx` | 当前旅行计划设置、文字与批量链接导入、来源库、候选确认、来源详情编辑/删除、地点池分类筛选、点击/拖拽脑图分配，以及总览与单日编辑页的地图、地点排序、备注和手动交通段交互。 |
| `src/features/plan/types.ts` | TravelPlan、POI、POI 来源、独立来源库记录、优先级、安排日期、地图位置确认、单日顺序与手动交通段的数据模型。 |
| `src/features/plan/seed.ts` | 当前开发阶段使用的示例旅行计划。 |
| `src/features/plan/PlanProvider.tsx` | React Context + useReducer 的旅行计划状态管理，包含导入去重、来源库状态、来源管理、优先级/日期独立更新、单日排序、手动交通段与用户确认的位置保存。 |
| `src/features/plan/storage.ts` | 版本化 localStorage 的读取、校验、保存，以及旧版互斥状态、位置确认、来源库和单日交通段的兼容迁移。 |
| `src/features/import/extractCandidates.ts` | 文字攻略的保守候选提取：清单和路线结构优先、路线描述过滤及交通站点分流。 |
| `src/features/map/AmapMap.tsx` | 高德 JS API 的在线加载、当前城市底图、已确认 POI 的状态色标记、脑图聚焦平移和地图标记点击回调；Key 缺失或加载失败时受控降级。 |
| `src/features/map/poiSearch.ts` | 浏览器端 POI 候选查询客户端；只请求本地代理，不接触 Web 服务 Key。 |
| `src/step-two.css` | 行程设置弹窗、动态脑图网格布局及设置入口样式。 |
| `vite.config.ts` | Vite 配置及开发环境 `/api/poi-search` 代理：验证地点名和城市 adcode 后按需请求高德 Web 服务。 |
| `.env.example` | 高德地图浏览器端 Key、安全密钥及仅服务端使用的 Web 服务 Key 示例。 |
| `src/vite-env.d.ts` | Vite 环境变量的 TypeScript 类型声明。 |
| `style.css` | 从原型保留的共享视觉样式。 |
| `app.js` | 旧版原生 JavaScript 原型逻辑；不再由当前入口加载，后续步骤按需迁移而非继续修改。 |
| `package.json` | React、TypeScript、Vite 与 `@dnd-kit/core` 依赖和本地开发/构建脚本。 |
| `vite.config.ts`、`tsconfig*.json` | Vite 与 TypeScript 配置。 |
| `PRD.md` | 早期需求记录，保留供追溯。 |
| `memory-bank/design-document.md` | 当前产品行为、数据模型和验收标准的依据。 |
| `memory-bank/tech-stack.md` | 当前技术选型与接口边界的依据。 |
| `memory-bank/implementation-plan.md` | 唯一允许按步骤执行的开发计划。 |
| `memory-bank/progress.md` | 已完成步骤与用户验收记录。 |

## 当前请求边界

```text
React 单页应用
  ├─ 旅行计划与本地保存
  ├─ 导入、候选确认、去重与来源管理
  ├─ 标签池与旅行脑图
  └─ 高德地图组件
          │
          └─ 本地开发代理 `/api/poi-search`
                 ├─ 从非 `VITE_` 环境变量读取高德 Web 服务 Key
                 ├─ 按“地点名 + 城市 adcode”返回最多 5 个候选
                 └─ 浏览器仅保存用户确认的 POI ID、坐标与地址
```

已确认位置的 POI 会传入地图组件生成标记：必去为红色、待定为黄色、已安排为绿色，其他已确认地点为中性色。交通节点为短胶囊，其他地点为圆形。地图标记第一次点击聚焦至 18 级，第二次打开旁栏地点卡。App 管理地图焦点、分组筛选和底部安排面板的展开状态；地点卡支持优先级、日期、备注及折叠来源。地点池与安排面板的拖拽使用独立 ID，通过 data.poiId 关联同一个 POI。

AmapMap 将标记更新与相机移动拆成独立 effect。只有焦点地点或坐标变化才重新聚焦，日期、备注、分组筛选和关闭详情不重置视野。分组筛选仅淡化非目标标记，不移除其点击能力。step-two.css 定义左地点池、右地图、底部安排和地图旁地点卡的响应式布局，桌面同屏展示。

POI 的 note 字段保存个人备注，transportType 保存交通节点种类；DayPlan 的 poiIds 保存当日排序，transportSegments 保存相邻地点间由用户手动选择的交通方式与预计分钟数。PlanProvider 在排序、日期变更或删除地点时，仅保留仍相邻的交通段；清空地点池同时清除所有交通段，但保留 sourceLibrary 和行程设置。版本一的独立快照位于项目相邻目录，不参与原项目后续修改。

来源库记录用户主动输入的每条攻略链接或文字来源。批量链接界面先从完整分享文案中提取 URL，生成可编辑、可删除的独立收集卡片，用户确认后再统一保存；当前对小红书链接只保存链接并标记为“等待补充文字”，不尝试读取页面。用户可从同一来源卡进入文字兜底，完成 POI 提取后来源状态变为“已用文字整理”。删除来源卡会先计算并提示没有其他来源的 POI 数量；确认后仅删除这些唯一关联地点，其他地点保留并移除该来源关联。

Agent-Reach/OpenCLI 仅存在于开发者个人电脑，用来验证公开笔记读取在本机测试账号会话中的技术可行性；它不是应用依赖，不被 Vite 接口调用，也不属于将来网页或线上部署的架构。正式内容读取只能替换为已取得授权的服务端适配器。

2026-10-12：生产接口已实现为 Vercel Serverless 入口，等待实际部署。Vite 本地中间件和 `api/*.js` 都复用 `server/api.mjs` + Node 适配器；生产静态预览自身不提供接口。

## 投递版扩展架构（2026-10-12）

- `/api/config` 只输出 AI 和地图搜索是否可用，不输出任何密钥。
- `/api/poi-search` 按城市查询少量地点候选；`/api/city-search` 确认非预置城市的行政编码。
- `/api/extract-pois` 仅在服务端配置模型 Key 和名称时调用模型；输入为用户主动提交的文字。候选需含真实原文证据，经过结构校验与用户确认，不能替代地图核验。默认使用前端规则。
- API 使用 Web Request/Response，提供请求大小限制、上游超时、通用错误和单实例限流。公开规模扩大前需另配全局限流/预算限制；当前实现不声称跨实例限流。
- 空个人计划与杭州示例采用独立存储键。导出/恢复功能保留来源、坐标、日期、排序及手动交通段；恢复文件先做结构与来源协议校验。
- `ReleaseUi.tsx` 管理引导、手动补充和备份下载；`release.css` 增补响应式和焦点样式。`style.css` 仍由当前入口加载，不应删除。
- Node 内置测试经 TypeScript 转译钩子加载状态模块。CI 为测试与构建配置，尚未远程运行。

## 不变量

浅色旅行册改版：DraggablePoiChip 增加类别 SVG 图标、真实类别标签和独立必去星标，星标复用 set-poi-arrangement，仅变更 priority。Branch 使用 data-day 表达日期主题；状态、存储、地图接口和地图相机逻辑不变。

- 每份计划只有一个中国大陆城市，旅行天数为 2–5 天。
- 地点的优先级（普通、必去、待定）与安排日期（未安排或某一天）相互独立；脑图避免同一地点在多个节点重复显示。
- 重复地点合并后保留全部来源。
- 地图位置必须经用户确认后才作为准确标记保存。
- 浏览器不保存或复制全量 POI 库；每次仅按需查询当前 POI 的少量候选。
- 链接读取不可用时，文字粘贴闭环必须可用。
